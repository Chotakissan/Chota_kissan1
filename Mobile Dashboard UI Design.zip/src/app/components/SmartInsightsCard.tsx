import { Play, Battery, Droplets, Lightbulb } from 'lucide-react';

interface Insight {
  icon: React.ElementType;
  text: string;
  kannada: string;
  type: 'success' | 'warning' | 'info';
}

interface SmartInsightsCardProps {
  batteryPercent: number;
  tankPercent: number;
  loadPercent: number;
}

export default function SmartInsightsCard({ batteryPercent, tankPercent, loadPercent }: SmartInsightsCardProps) {
  const insights: Insight[] = [];

  if (batteryPercent > 50 && tankPercent > 30 && loadPercent < 80) {
    insights.push({
      icon: Play,
      text: 'Continue Working',
      kannada: 'ಮುಂದುವರಿಸಿ',
      type: 'success'
    });
  }

  if (batteryPercent <= 20) {
    insights.push({
      icon: Battery,
      text: 'Return to Charge',
      kannada: 'ಚಾರ್ಜ್ ಮಾಡಿ',
      type: 'warning'
    });
  }

  if (tankPercent <= 30) {
    insights.push({
      icon: Droplets,
      text: 'Refill Tank',
      kannada: 'ಟ್ಯಾಂಕ್ ತುಂಬಿಸಿ',
      type: 'warning'
    });
  }

  const getInsightColor = (type: Insight['type']) => {
    switch (type) {
      case 'success':
        return 'bg-green-100 border-green-300 text-green-800';
      case 'warning':
        return 'bg-yellow-100 border-yellow-300 text-yellow-800';
      case 'info':
        return 'bg-blue-100 border-blue-300 text-blue-800';
    }
  };

  return (
    <div className="bg-white rounded-3xl p-6 shadow-lg">
      <div className="flex items-center gap-3 mb-6">
        <Lightbulb className="w-10 h-10 text-yellow-600" strokeWidth={1.5} />
        <div>
          <h2 className="text-gray-700">Smart Insights</h2>
          <p className="text-sm text-gray-500">ಸ್ಮಾರ್ಟ್ ಸಲಹೆಗಳು</p>
        </div>
      </div>

      <div className="space-y-4">
        {insights.map((insight, index) => {
          const Icon = insight.icon;
          return (
            <div
              key={index}
              className={`flex items-center gap-4 p-4 rounded-2xl border-2 ${getInsightColor(insight.type)}`}
            >
              <Icon className="w-8 h-8 flex-shrink-0" strokeWidth={2} />
              <div className="flex-1">
                <p className="font-semibold text-lg">{insight.text}</p>
                <p className="text-sm">{insight.kannada}</p>
              </div>
            </div>
          );
        })}

        {insights.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            <p>All systems normal</p>
            <p className="text-sm">ಎಲ್ಲಾ ವ್ಯವಸ್ಥೆಗಳು ಸಾಮಾನ್ಯ</p>
          </div>
        )}
      </div>
    </div>
  );
}
