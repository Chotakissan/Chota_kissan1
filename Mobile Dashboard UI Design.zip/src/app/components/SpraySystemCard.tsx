import { Droplets, AlertTriangle } from 'lucide-react';

interface SpraySystemCardProps {
  tankLevelPercent: number;
  litersRemaining: number;
  sprayRate: number;
  pressure: number;
}

export default function SpraySystemCard({ tankLevelPercent, litersRemaining, sprayRate, pressure }: SpraySystemCardProps) {
  const needsRefill = tankLevelPercent < 30;

  return (
    <div className="bg-white rounded-3xl p-6 shadow-lg">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-gray-700">Spray System</h2>
          <p className="text-sm text-gray-500">ಸ್ಪ್ರೆ ವ್ಯವಸ್ಥೆ</p>
        </div>
        <Droplets className="w-10 h-10 text-blue-600" strokeWidth={1.5} />
      </div>

      <div className="flex gap-6 mb-6">
        <div className="relative w-16 h-48 bg-gray-200 rounded-full overflow-hidden">
          <div
            className={`absolute bottom-0 w-full transition-all ${
              tankLevelPercent > 50 ? 'bg-blue-500' : tankLevelPercent > 20 ? 'bg-yellow-500' : 'bg-red-500'
            }`}
            style={{ height: `${tankLevelPercent}%` }}
          />
        </div>

        <div className="flex-1">
          <div className="mb-4">
            <p className="text-sm text-gray-600 mb-1">Tank Level</p>
            <p className="text-xs text-gray-500 mb-2">ಟ್ಯಾಂಕ್ ಮಟ್ಟ</p>
            <p className="text-5xl font-bold text-gray-900">{tankLevelPercent}%</p>
          </div>

          <div className="bg-gray-50 rounded-2xl p-3">
            <p className="text-xs text-gray-600">Remaining</p>
            <p className="text-2xl font-semibold text-gray-900">{litersRemaining}L</p>
          </div>
        </div>
      </div>

      {needsRefill && (
        <div className="bg-yellow-100 border-2 border-yellow-400 rounded-2xl p-4 mb-4 flex items-center gap-3">
          <AlertTriangle className="w-8 h-8 text-yellow-700 flex-shrink-0" />
          <div>
            <p className="font-semibold text-yellow-900">Refill Soon</p>
            <p className="text-sm text-yellow-800">ತುಂಬಿಸಿ</p>
          </div>
        </div>
      )}

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-gray-50 rounded-2xl p-4">
          <p className="text-sm text-gray-600 mb-1">Spray Rate</p>
          <p className="text-xs text-gray-500 mb-2">ಸ್ಪ್ರೆ ದರ</p>
          <p className="text-2xl font-semibold text-gray-900">{sprayRate} L/min</p>
        </div>

        <div className="bg-gray-50 rounded-2xl p-4">
          <p className="text-sm text-gray-600 mb-1">Pressure</p>
          <p className="text-xs text-gray-500 mb-2">ಒತ್ತಡ</p>
          <p className="text-2xl font-semibold text-gray-900">{pressure} bar</p>
        </div>
      </div>
    </div>
  );
}
