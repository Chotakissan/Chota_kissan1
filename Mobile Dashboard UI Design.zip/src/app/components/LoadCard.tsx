import { Scale, AlertCircle, CheckCircle } from 'lucide-react';

interface LoadCardProps {
  currentLoad: number;
  maxCapacity: number;
}

export default function LoadCard({ currentLoad, maxCapacity }: LoadCardProps) {
  const remainingCapacity = maxCapacity - currentLoad;
  const loadPercent = (currentLoad / maxCapacity) * 100;

  const getStatus = () => {
    if (loadPercent > 95) return { text: 'OVERLOAD', kannada: 'ಅತಿ ಭಾರ', color: 'bg-red-500', icon: AlertCircle };
    if (loadPercent > 80) return { text: 'NEAR LIMIT', kannada: 'ಮಿತಿ ಹತ್ತಿರ', color: 'bg-yellow-500', icon: AlertCircle };
    return { text: 'SAFE', kannada: 'ಸುರಕ್ಷಿತ', color: 'bg-green-500', icon: CheckCircle };
  };

  const status = getStatus();
  const StatusIcon = status.icon;

  return (
    <div className="bg-white rounded-3xl p-6 shadow-lg">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-gray-700">Load</h2>
          <p className="text-sm text-gray-500">ಭಾರ</p>
        </div>
        <Scale className="w-10 h-10 text-gray-700" strokeWidth={1.5} />
      </div>

      <div className="mb-6">
        <div className="flex items-baseline gap-2 mb-2">
          <span className="text-6xl font-bold text-gray-900">{currentLoad}</span>
          <span className="text-2xl text-gray-600">kg</span>
        </div>

        <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full ${status.color} text-white`}>
          <StatusIcon className="w-5 h-5" />
          <span className="font-semibold">{status.text}</span>
          <span className="text-sm">({status.kannada})</span>
        </div>
      </div>

      <div className="w-full bg-gray-200 rounded-full h-4 mb-6 overflow-hidden">
        <div
          className={`h-full rounded-full transition-all ${status.color}`}
          style={{ width: `${loadPercent}%` }}
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-gray-50 rounded-2xl p-4">
          <p className="text-sm text-gray-600 mb-1">Capacity</p>
          <p className="text-xs text-gray-500 mb-2">ಸಾಮರ್ಥ್ಯ</p>
          <p className="text-2xl font-semibold text-gray-900">{maxCapacity} kg</p>
        </div>

        <div className="bg-gray-50 rounded-2xl p-4">
          <p className="text-sm text-gray-600 mb-1">Remaining</p>
          <p className="text-xs text-gray-500 mb-2">ಉಳಿದಿದೆ</p>
          <p className="text-2xl font-semibold text-gray-900">{remainingCapacity} kg</p>
        </div>
      </div>
    </div>
  );
}
