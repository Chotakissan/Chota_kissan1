import { Battery, BatteryLow, BatteryWarning } from 'lucide-react';

interface BatteryCardProps {
  percentage: number;
  timeRemaining: number;
  distancePossible: number;
}

export default function BatteryCard({ percentage, timeRemaining, distancePossible }: BatteryCardProps) {
  const getStatus = () => {
    if (percentage > 50) return { text: 'GOOD', kannada: 'ಉತ್ತಮ', color: 'bg-green-500', icon: Battery };
    if (percentage > 20) return { text: 'LOW', kannada: 'ಕಡಿಮೆ', color: 'bg-yellow-500', icon: BatteryWarning };
    return { text: 'CRITICAL', kannada: 'ಅಪಾಯ', color: 'bg-red-500', icon: BatteryLow };
  };

  const status = getStatus();
  const StatusIcon = status.icon;

  return (
    <div className="bg-white rounded-3xl p-6 shadow-lg">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-gray-700">Battery</h2>
          <p className="text-sm text-gray-500">ಬ್ಯಾಟರಿ</p>
        </div>
        <StatusIcon className="w-10 h-10 text-gray-700" strokeWidth={1.5} />
      </div>

      <div className="mb-6">
        <div className="flex items-baseline gap-2 mb-2">
          <span className="text-6xl font-bold text-gray-900">{percentage}</span>
          <span className="text-3xl text-gray-600">%</span>
        </div>

        <div className={`inline-block px-4 py-2 rounded-full ${status.color} text-white`}>
          <span className="font-semibold">{status.text}</span>
          <span className="ml-2 text-sm">({status.kannada})</span>
        </div>
      </div>

      <div className="w-full bg-gray-200 rounded-full h-4 mb-6 overflow-hidden">
        <div
          className={`h-full rounded-full transition-all ${status.color}`}
          style={{ width: `${percentage}%` }}
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-gray-50 rounded-2xl p-4">
          <p className="text-sm text-gray-600 mb-1">Time Left</p>
          <p className="text-xs text-gray-500 mb-2">ಉಳಿದ ಸಮಯ</p>
          <p className="text-2xl font-semibold text-gray-900">{timeRemaining}h</p>
        </div>

        <div className="bg-gray-50 rounded-2xl p-4">
          <p className="text-sm text-gray-600 mb-1">Distance</p>
          <p className="text-xs text-gray-500 mb-2">ದೂರ</p>
          <p className="text-2xl font-semibold text-gray-900">{distancePossible} km</p>
        </div>
      </div>
    </div>
  );
}
