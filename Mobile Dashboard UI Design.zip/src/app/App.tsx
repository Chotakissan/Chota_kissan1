import { useState } from 'react';
import BatteryCard from './components/BatteryCard';
import SpraySystemCard from './components/SpraySystemCard';
import LoadCard from './components/LoadCard';
import SmartInsightsCard from './components/SmartInsightsCard';

export default function App() {
  const [batteryPercent] = useState(75);
  const [timeRemaining] = useState(4);
  const [distancePossible] = useState(12);

  const [tankLevelPercent] = useState(45);
  const [litersRemaining] = useState(18);
  const [sprayRate] = useState(2.5);
  const [pressure] = useState(3.2);

  const [currentLoad] = useState(35);
  const [maxCapacity] = useState(50);

  const loadPercent = (currentLoad / maxCapacity) * 100;

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100">
      <div className="max-w-[360px] mx-auto">
        <div className="bg-gradient-to-r from-green-600 to-green-700 text-white p-6 shadow-lg">
          <h1 className="text-3xl font-bold mb-1">Chota Kisan</h1>
          <p className="text-green-100">ಚೋಟಾ ಕಿಸಾನ್ ರೊಬೊಟ್</p>
        </div>

        <div className="p-4 space-y-4 pb-8">
          <BatteryCard
            percentage={batteryPercent}
            timeRemaining={timeRemaining}
            distancePossible={distancePossible}
          />

          <SpraySystemCard
            tankLevelPercent={tankLevelPercent}
            litersRemaining={litersRemaining}
            sprayRate={sprayRate}
            pressure={pressure}
          />

          <LoadCard
            currentLoad={currentLoad}
            maxCapacity={maxCapacity}
          />

          <SmartInsightsCard
            batteryPercent={batteryPercent}
            tankPercent={tankLevelPercent}
            loadPercent={loadPercent}
          />
        </div>
      </div>
    </div>
  );
}